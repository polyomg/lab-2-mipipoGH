package poly.edu.entity;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class product {
    String name;
    Double price;
}
